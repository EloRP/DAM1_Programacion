package calculosoperadores;

import java.util.Scanner;

public class E01011 {
public static void main(String[] args) {
   
    Scanner sc = new Scanner (System.in);

    System.out.print("Ventas de manzanas en kilos en el primer semestre: ");
    double ventasManzanaSemestre1 = sc.nextDouble();

    System.out.print("Venta de manzanas en kilos en el segundo semestre ");
    double ventasManzanaSemestre2 = sc.nextDouble();

    System.out.println("Venta de peras en kilos en el primer semestre ");
    double ventasPeraSemestre1 = sc.nextDouble();
    }
    
}
