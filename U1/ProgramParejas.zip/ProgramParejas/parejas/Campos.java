package Parejas;

        //... Alberto Ameneiros (Driver) Angel Barral (navigator)

import java.util.Scanner;

public class Campos {
    public static void main(String[] args) {

        double hect = 100 * 100;
        double camFut = 105 * 79, camBal = 28 * 15, camTen = 23.77 * 10.97, retiro = (125 * 10000);

        System.out.println("Coloque las hectareas dañadas: ");
        Scanner sc = new Scanner(System.in);

        double danos = sc.nextDouble();
        double totalHect = danos * hect;

        System.out.println("Equivale a: " + (totalHect / camFut) + " campos de futbol");
        System.out.println("Equivale a: " + (totalHect / camBal) + " campos de baloncesto");
        System.out.println("Equivale a: " + (totalHect / camTen) + " campos de tenis");
        System.out.println("Equivale a: " + (totalHect / retiro) + " parques de retiro");


        //... 
    }
}
