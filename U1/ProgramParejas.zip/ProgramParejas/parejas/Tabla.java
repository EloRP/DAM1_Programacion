package parejas;

import java.util.Scanner;

/* Angel Barral (driver), Alberto Ameneiros (navigator) */
public class Tabla {
    public static void main(String[] args) {

    char r1 , r2 , r3 , r4 , r5 , r6;
    float nota = 0;
    Scanner sc = new Scanner(System.in);

    System.out.println("responde con 's', 'm' o 'n'");
    System.out.print("El programa funciona?(s=4, m=2, n=0)");
    r1 = sc.next().charAt(0);
    nota = (r1 == 's') ? nota + 4 : (r1 == 'm')? nota + 2 : nota + 0;

    System.out.print("El programa funciona y es eficiente?(s=1, m=0.5, n=0)");
    r2 = sc.next().charAt(0);
    nota = (r2 == 's') ? nota + 1 : (r2 == 'm')? nota + 0.5f : nota + 0;

    System.out.print("El programa usa estructuras y datos adecuados?(s=1, m=0.5, n=0)");
    r3 = sc.next().charAt(0);
    nota = (r3 == 's') ? nota + 1 : (r3 == 'm')? nota + 0.5f : nota + 0;

    System.out.print("El programa usa identificadores adecuados?(s=1.5, m=0.75, n=0)");
    r4 = sc.next().charAt(0);
    nota = (r4 == 's') ? nota + 1.5f : (r4 == 'm')? nota + 0.75f : nota + 0;

    System.out.print("El programa es legible?(s=1.5, m=0.75, n=0)");
    r5 = sc.next().charAt(0);
    nota = (r5 == 's') ? nota + 1.5f : (r5 == 'm')? nota + 0.75f : nota + 0;

    System.out.print("El programa presenta la informacion completa?(s=1, m=0.5, n=0)");
    r6 = sc.next().charAt(0);
    nota = (r6 == 's') ? nota + 1 : (r6 == 'm')? nota + 0.5f : nota + 0;

    System.out.println("La nota final es: " + nota);
    
    }    
}
