package parejas;

import java.util.Scanner;

/* Angel Barral (driver), Alberto Ameneiros (navigator) */
public class Receta {
    public static void main(String[] args) {

        double manzana = 1.5 / 6;
        double agua = 300 / 6;
        double azucar = 120 / 6;
        double limon = 1 / 6.0;
        byte persona;
        Scanner sc = new Scanner(System.in);

        System.out.println("Receta de Compota de Manzana");
        System.out.println("https://www.recetasderechupete.com/compota-de-manzana-casera/12509/");
        System.out.println("para 6 personas");
        System.out.println("Ingredientes: 1.5kg de manzana, 300ml de agua, 120g de azucar, 1 cucharadita de zumo de limon");

        System.out.print("Para cuantas personas? ");
        persona = sc.nextByte();
        manzana = manzana * persona;
        agua = agua * persona;
        azucar = azucar * persona;
        limon = limon * persona;

        System.out.println("Los ingredientes para " + persona + " persona/s son: "
            + manzana + "kg de manzana, "
            + agua + "ml de agua, "
            + azucar + "g de azucar, "
            + Math.round(limon) + " cucharadita/s de zumo de limon");

    }

}
