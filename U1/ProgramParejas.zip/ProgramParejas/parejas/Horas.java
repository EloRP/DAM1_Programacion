package Parejas;

import java.util.Scanner;

//... Alberto Ameneiros (Driver) Angel Barral (navigator)

public class Horas {
    public static void main(String[] args) {

    final String MODULO = "Programacion";
    double horas = 240, faltasMax = horas * 0.06, sinPerMax = horas *0.1;

    Scanner sc = new Scanner(System.in);
    
    System.out.println("Introduzca su numero de faltas (sesiones): ");

    int faltas = sc.nextInt();
    double sesFalt = faltas * 8.33;

    String resPer = sesFalt >= (sinPerMax) ? " Pierde la evaluacion" : sesFalt >= (faltasMax) ? " Sigue en la evaluacion" : " Pierde la evaluacion";
    System.out.println("Usted" + resPer);

    }
}
