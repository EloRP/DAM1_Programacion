/*Eloy Rodal Pérez DAM1 5-10-2023 */

package examenud01;

import java.util.Scanner;

public class ComidaEnGrupo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Escribe aquí el número de comensales");
        int numComensales = sc.nextInt();

        System.out.println("Y aquí el importe de la comida");
        float importeComida = sc.nextFloat();

        double importePorPersona = importeComida / numComensales;

        System.out.println("Número de personas: " + numComensales);
        System.out.println("Importe total de la comida (euros): " + importeComida);
        System.out.println("Cantidad total a pagar por comensal: " + (importePorPersona) + " euros");

        sc.close();
    }
}
