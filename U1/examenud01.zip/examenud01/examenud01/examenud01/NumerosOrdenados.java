/*Eloy Rodal Pérez DAM1 5-10-2023 */

package examenud01;

import java.util.Scanner;

public class NumerosOrdenados {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double primerValor;
        double segundoValor;
        double tercerValor;

        System.out.println("Introduce 3 números (pulsa ENTER después de cada uno): ");
        double valorUno = sc.nextDouble();
        double valorDos = sc.nextDouble();
        double valorTres = sc.nextDouble();

        boolean mayorAMenor = mayorAMenor;
        mayorAMenor = primerValor > segundoValor > tercerValor ? "Ordenados de mayor a menor" : "Números desordenados";

    }
}
