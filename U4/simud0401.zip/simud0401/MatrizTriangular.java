package simud0401;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class MatrizTriangular {

    public static Boolean esTriangular(int[][] t) {
        int[][] tr = null;
        if (esMatrizValida(t)) { // Comprueba si es matriz válida
            if (esCuadrada(t)) { // Comprueba si es cuadrada
                
            return true;
            }
        }
            return false;
    }

    public static Boolean esMatrizValida(int[][] t) {
        return t != null && t.length > 0 && t[0].length > 0;
    }

    public static Boolean esCuadrada(int[][] t) {
        Boolean res = null;

        if (esMatrizValida(t)) {
            res = t.length == t[0].length;
        }

        return res;
    }

    /**
     * TESTS JUNIT 5
     */
    @Test
    public void matrizTriangularSuperior() {
        int[][] matriz = {
                { 1, 2, 3 },
                { 0, 4, 5 },
                { 0, 0, 6 }
        };
        assertTrue(esTriangular(matriz));
    }

    @Test
    public void matrizTriangularInferior() {
        int[][] matriz = {
                { 1, 0, 0 },
                { 4, 5, 0 },
                { 7, 8, 9 }
        };
        assertTrue(esTriangular(matriz));
    }

    @Test
    public void matrizNoTriangular() {
        int[][] matriz = {
                { 1, 2, 3 },
                { 4, 5, 6 },
                { 7, 8, 9 }
        };
        assertFalse(esTriangular(matriz));
    }

    @Test
    public void matrizVacia() {
        int[][] matriz = {};
        assertFalse(esTriangular(matriz));
    }

    @Test
    public void matrizNoCuadrada() {
        int[][] matriz = {
                { 1, 2, 3 },
                { 4, 5, 6 }
        };
        assertFalse(esTriangular(matriz));
    }
}