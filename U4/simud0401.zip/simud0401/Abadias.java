package simud0401;

import java.util.Scanner;

public class Abadias {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int altura;
        int[] numMontañas = new int[1000];

        int i = 0;
        int montañaActual = 1;
        System.out.println("Introduce las alturas de las montañas (De OESTE a ESTE, introduce -1 para acabar.)");
        while (true) {
            System.out.println("Altura de la montaña " + montañaActual + ":");
            altura = sc.nextInt();

            if (altura == -1) {
                break;
            }

            numMontañas[i] = altura;
            i++;
        }
        }
    }
