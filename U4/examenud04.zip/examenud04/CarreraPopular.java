package examenud04;

import java.util.Arrays;
import java.util.Scanner;

public class CarreraPopular {
    public static void main(String[] args) {
        String[] datosParticipantes = new String[0];
        System.out.println("Registro de carrera.");
        lecturaParticipantes();
        System.out.println("Lista de participantes: " + datosParticipantes.toString());
        System.out.println("Hay " + "en total. Hay " + participantesHermanos(datosParticipantes)
                + "participantes hermanos.");
    }

    public static int participantesHermanos(String[] participantes) {
        int guebos = 0;
        return guebos;
    }

    public static String[] lecturaParticipantes() {
        String[] participantes = new String[0];
        Scanner sc = new Scanner(System.in);
        String inputDatos = " ";
        int contadorParticipantes = 0;
        while (!inputDatos.equals("===")) {
            contadorParticipantes++;
            System.out.println("Participante " + contadorParticipantes + " (Apellidos, Nombre): ");
            inputDatos = sc.nextLine();
            comprobarFormato();
            if (comprobarFormato() == false) {
                System.out.println("Formato incorrecto.");
                break;
            }
        }
        sc.close();
        Arrays.sort(participantes);
        return participantes;
    }

    public static boolean comprobarFormato() {
        boolean formatoCorrecto = false;
        String inputUsuario = "";
        String entradaApropiada = String.format(" , ");
        if (inputUsuario.equals(entradaApropiada)) {
            formatoCorrecto = true;
        }
        return formatoCorrecto;

    }
}

/*
 * if (palabras.length > 0) {
 * System.out.print(palabras[0] + "\n");
 * 
 * for (int i = 1; i < palabras.length; i++) {
 * System.out.println("\t" + palabras[i]);
 * }
 * }
 * sc.close();
 */