package examenud04;

import java.util.Scanner;

public class RecorridoRobot {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String instrucciones;
        System.out.println("Bienvenido al juego del robot.");
        System.out.println("Tienes tres instrucciones, A, R o L. Elige.");
        System.out
                .println(" una A hará que el robot avance una casilla en la dirección en la que está orientado.\r\n" + //
                        " una R hará que la orientación del robot gire a la derecha 90º sin moverse del sitio.\r\n" + //
                        " una L hará que la orientación del robot gire a la izquierda 90º sin moverse del sitio");
        String[] mapa = creacionMapa();
        creacionMapa(mapa);
        System.out.println("Escribe las instrucciones en una cadena de caracteres, tal que así: AALARAARAA");
        instrucciones = sc.nextLine();
        System.out.println(recorridoRobot(mapa, instrucciones, 0, 0));
    }

    static String[] creacionMapa() {
        String[] mapa = {
                "  Z       ",
                " *        ",
                "  *  *    ",
                "          ",
                " A        "
        };

        return mapa;
    }

    static boolean recorridoRobot(String[] mapa, String instrucciones, int xA, int yA) {
        boolean llegada = false;
        char direccion = 'U';
        posicion(mapa);

        for (int i = 0; i < instrucciones.length(); i++) {
            if (instrucciones.charAt(i) == 'A') {
                switch (direccion) {
                    case 'A':
                        yA--;
                        break;
                    case 'R':
                        yA++;
                        break;
                    case 'L':
                        xA++;
                        break;
                    default:
                        System.out.println("Error de input, vuelve a intentarlo.");
                        break;
                }
            } else if (instrucciones.charAt(i) == 'R') {
                switch (direccion) {
                    case 'U':
                        direccion = 'R';
                        break;
                    case 'D':
                        direccion = 'L';
                        break;
                    case 'L':
                        direccion = 'U';
                        break;
                    default:
                        System.out.println("Error de input, vuelve a intentarlo.");
                        break;
                }
            }
        }
        return llegada;
    }

    static void posicion(String[] mapa) {
        int x;
        int y;
        for (int i = 0; i < mapa.length; i++) {
            x = 0;
            y = 0;
        }
    }

    static void creacionMapa(String[] mapa) {
        for (int i = 0; i < mapa.length; i++) {
            System.out.println(mapa[i]);
        }
    }
}