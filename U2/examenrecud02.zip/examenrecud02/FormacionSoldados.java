package examenrecud02;
//Eloy Rodal Pérez
public class FormacionSoldados {
    
}
